// SPDX-License-Identifier: AGPL-3.0-or-later
// SPDX-FileCopyrightText: 2026 Jareer and Concat contributors

//! What the window asks of the platform it runs on.
//!
//! Four things differ between a desk and a phone: how the backend is
//! chosen, how a file or folder is picked, whether the window has a title
//! strip of its own to drag, and whether a file dragged in from outside the
//! window is even a thing that can happen. Everything else in the crate is
//! the same tree, the same state and the same callbacks, so the differences
//! live here and nowhere else.
//!
//! Desktop and iOS draw through the winit backend; Android through Slint's
//! android-activity backend, which the activity sets up before [`crate::run`]
//! is called. File dialogs are the desktop's: on a phone a pick goes through
//! the system's document picker, which arrives with the phone layout. A drag
//! in from the OS is a desktop thing for the same reason: winit reports
//! `DroppedFile` on macOS, Windows and X11, and not on iOS, which has no
//! such gesture - nor on Wayland, where the window listens for the drop
//! itself; see [`crate::wayland_drop`].

use std::path::PathBuf;

use slint::PlatformError;
// The winit backend, and so these, exist everywhere but Android, which
// draws through Slint's android-activity backend and has no winit at all.
#[cfg(not(target_os = "android"))]
use slint::winit_030::winit::event::{ElementState, MouseButton, WindowEvent};
#[cfg(not(target_os = "android"))]
use slint::winit_030::winit::event_loop::ActiveEventLoop;
#[cfg(not(target_os = "android"))]
use slint::winit_030::winit::window::{Window as WinitWindow, WindowId};
#[cfg(not(target_os = "android"))]
use slint::winit_030::{CustomApplicationHandler, EventResult};

use crate::gpu::Gpu;

/// The interface scale the person chose, as a percent of the display's
/// own; 0 follows the display. See [`apply_ui_scale`].
static UI_SCALE: std::sync::atomic::AtomicU32 = std::sync::atomic::AtomicU32::new(0);

/// Remembers the interface scale [`apply_ui_scale`] applies: a percent of
/// the display's own scale, or `None` for the display's.
pub fn set_ui_scale(percent: Option<u32>) {
    UI_SCALE.store(percent.unwrap_or(0), std::sync::atomic::Ordering::Relaxed);
}

/// Scales `window` to the display's own scale times the chosen percent.
///
/// Not through SLINT_SCALE_FACTOR, as it was: Slint takes that as the
/// whole factor, not a multiplier, and ignores the display's scale while
/// it is set, so "100 %" made the interface smaller on a Windows laptop at
/// 150 % and halved it on a Retina Mac, and moving the window to another
/// monitor no longer rescaled it. The display's scale is winit's, which no
/// dispatch here changes; this runs when the window first shows, when the
/// choice changes, and after every move to a monitor of another scale. A
/// SLINT_SCALE_FACTOR set by hand still wins, and then nothing is done.
/// https://github.com/jub0t/Concat/issues/320
#[cfg(not(target_os = "android"))]
pub fn apply_ui_scale(window: &slint::Window) {
    use slint::winit_030::WinitWindowAccessor;
    if std::env::var_os("SLINT_SCALE_FACTOR").is_some() {
        return;
    }
    let Some(native) = window.with_winit_window(|winit| winit.scale_factor()) else {
        return;
    };
    let percent = UI_SCALE.load(std::sync::atomic::Ordering::Relaxed);
    let chosen = if percent == 0 {
        1.0
    } else {
        crate::prefs::Preferences::scale_factor(percent)
    };
    let factor = (native * chosen) as f32;
    if (window.scale_factor() - factor).abs() < 1e-3 {
        return;
    }
    log::info!("interface scale: the display's {native} times {chosen} is {factor}");
    let physical = window.size();
    window.dispatch_event(slint::platform::WindowEvent::ScaleFactorChanged {
        scale_factor: factor,
    });
    window.dispatch_event(slint::platform::WindowEvent::Resized {
        size: physical.to_logical(factor),
    });
}

/// A phone sets its size the system's way; there is nothing to scale.
#[cfg(target_os = "android")]
pub fn apply_ui_scale(_window: &slint::Window) {}

/// [`apply_ui_scale`] on the open window, once the event in hand is done:
/// Slint applies a display's own scale as it handles the event, and the
/// chosen percent goes on top of that afterwards.
#[cfg(not(target_os = "android"))]
fn reapply_ui_scale() {
    slint::Timer::single_shot(std::time::Duration::ZERO, || {
        crate::host::Shell::with(|_, app| {
            apply_ui_scale(slint::ComponentHandle::window(&app));
        });
    });
}
/// The window's raw events, seen before Slint routes them. Two jobs:
///
/// Dropped files. winit reports one path per event, in a burst, and the
/// burst is over when the loop is about to wait, so the paths are held
/// and handed over together: one probe, one notice, however many files.
/// On Wayland winit reports nothing, and the window's own listener puts
/// the paths of a drop in `arrived` from its thread and wakes the loop,
/// which hands them over the same way.
///
/// A press away from the field being typed into. Slint keeps the focus
/// where it is until something else takes it, so a number field stayed in
/// its editing state - ring and all - through a click on a clip, a knob or
/// the monitor. Every press now passes through here first: if a text input
/// has the focus and the press is not on it, the window is asked to take
/// the focus back (App.blur) before Slint routes the press, and whatever
/// was pressed then takes the focus itself if it wants it - another input
/// does, so a click from one field into the next still lands a caret.
///
/// And on Linux, the window's edges. X11 and Wayland take the resize
/// borders away with the decorations, where Windows keeps them, so a
/// press within a few pixels of the frame is handed to the window manager
/// as a resize (winit's `drag_resize_window`) before Slint sees it, and
/// the pointer wears the matching arrow while it is there.
#[cfg(not(target_os = "android"))]
struct DropHandler {
    pending: Vec<PathBuf>,
    on_dropped: Box<dyn Fn(Vec<PathBuf>)>,
    /// Paths a Wayland drop delivered, from the listener's thread.
    arrived: std::sync::Arc<std::sync::Mutex<Vec<PathBuf>>>,
    /// The Wayland listener, once the window is up and is a Wayland one;
    /// `wayland_tried` says the question has been asked, whatever the
    /// answer, so it is asked once.
    wayland: Option<crate::wayland_drop::Listener>,
    wayland_tried: bool,
    /// Whether the window has been held to its screen yet: once, at its
    /// first event.
    fitted: bool,
    /// Where the pointer last was, in logical pixels of the window: winit
    /// says where it moved, and a press says only that it happened.
    cursor: Option<(f32, f32)>,
    on_pressed_away: Box<dyn Fn()>,
    /// The window came back to the front: the moment a person returns from
    /// moving a file, and the one where a file that went missing can be
    /// noticed. See `Studio::check_missing_media`.
    on_focused: Box<dyn Fn()>,
    /// Whether this window draws its own resize edges: Linux, undecorated.
    edges: bool,
    /// The edge the pointer is on, while it is on one.
    edge: Option<ResizeDirection>,
}

#[cfg(not(target_os = "android"))]
use slint::winit_030::winit::window::{CursorIcon, ResizeDirection};

/// How far in from the frame a press still resizes, in logical pixels.
/// Wide enough to find without aiming, narrow enough to leave the strip's
/// buttons and the panes' own edges theirs.
#[cfg(not(target_os = "android"))]
const EDGE: f64 = 6.0;

/// The edge of a `width` × `height` window that (`x`, `y`) is on, all in
/// physical pixels, with `band` the depth of an edge. Corners first, so the
/// diagonal wins where two edges meet.
#[cfg(not(target_os = "android"))]
fn edge_at(x: f64, y: f64, width: f64, height: f64, band: f64) -> Option<ResizeDirection> {
    let (west, east) = (x < band, x >= width - band);
    let (north, south) = (y < band, y >= height - band);
    Some(match (north, south, west, east) {
        (true, _, true, _) => ResizeDirection::NorthWest,
        (true, _, _, true) => ResizeDirection::NorthEast,
        (_, true, true, _) => ResizeDirection::SouthWest,
        (_, true, _, true) => ResizeDirection::SouthEast,
        (true, ..) => ResizeDirection::North,
        (_, true, ..) => ResizeDirection::South,
        (_, _, true, _) => ResizeDirection::West,
        (_, _, _, true) => ResizeDirection::East,
        _ => return None,
    })
}

#[cfg(not(target_os = "android"))]
fn edge_cursor(edge: ResizeDirection) -> CursorIcon {
    match edge {
        ResizeDirection::North => CursorIcon::NResize,
        ResizeDirection::South => CursorIcon::SResize,
        ResizeDirection::West => CursorIcon::WResize,
        ResizeDirection::East => CursorIcon::EResize,
        ResizeDirection::NorthWest => CursorIcon::NwResize,
        ResizeDirection::NorthEast => CursorIcon::NeResize,
        ResizeDirection::SouthWest => CursorIcon::SwResize,
        ResizeDirection::SouthEast => CursorIcon::SeResize,
    }
}

#[cfg(not(target_os = "android"))]
impl DropHandler {
    fn new(
        on_dropped: impl Fn(Vec<PathBuf>) + 'static,
        on_pressed_away: impl Fn() + 'static,
        on_focused: impl Fn() + 'static,
    ) -> Self {
        Self {
            pending: Vec::new(),
            on_dropped: Box::new(on_dropped),
            arrived: Default::default(),
            wayland: None,
            wayland_tried: false,
            fitted: false,
            cursor: None,
            on_pressed_away: Box::new(on_pressed_away),
            on_focused: Box::new(on_focused),
            edges: cfg!(not(any(
                target_os = "macos",
                target_os = "windows",
                target_os = "ios"
            ))) && !phone(),
            edge: None,
        }
    }
}

/// Whether a press at (`x`, `y`), in logical pixels of `window`, lands
/// away from the text input that has the focus. False when nothing has
/// it, when what has it is not a text input - a button keeps its focus
/// for the keyboard's sake - and when the press is on the input itself,
/// give or take a few pixels of its padding, which is where a caret is
/// placed rather than where a field is left.
#[cfg(not(target_os = "android"))]
fn press_misses_focused_input(window: &slint::Window, x: f32, y: f32) -> bool {
    use slint::private_unstable_api::re_exports::{LogicalPoint, TextInput, WindowInner};

    let focused = WindowInner::from_pub(window).focus_item.borrow().upgrade();
    let Some(item) = focused else {
        return false;
    };
    if item.downcast::<TextInput>().is_none() {
        return false;
    }
    const SLACK: f32 = 8.0;
    let origin = item.map_to_window(LogicalPoint::default());
    let size = item.geometry().size;
    let inside = x >= origin.x - SLACK
        && x <= origin.x + size.width + SLACK
        && y >= origin.y - SLACK
        && y <= origin.y + size.height + SLACK;
    !inside
}

#[cfg(not(target_os = "android"))]
impl CustomApplicationHandler for DropHandler {
    fn window_event(
        &mut self,
        _event_loop: &ActiveEventLoop,
        _window_id: WindowId,
        winit_window: Option<&WinitWindow>,
        slint_window: Option<&slint::Window>,
        event: &WindowEvent,
    ) -> EventResult {
        if !self.fitted
            && let Some(window) = winit_window
        {
            self.fitted = true;
            fit_to_screen(window);
        }
        if !self.wayland_tried
            && let Some(window) = winit_window
        {
            self.wayland_tried = true;
            self.wayland = listen_for_wayland_drops(window, &self.arrived);
        }
        match event {
            WindowEvent::ScaleFactorChanged { .. } => reapply_ui_scale(),
            WindowEvent::DroppedFile(path) => self.pending.push(path.clone()),
            // Back at the front, after Explorer or the file manager: what a
            // dropped file is to an import, a return is to a look for one
            // that went away while the window was open.
            WindowEvent::Focused(true) => (self.on_focused)(),
            WindowEvent::CursorMoved { position, .. } => {
                let scale = slint_window
                    .map(|window| f64::from(window.scale_factor()))
                    .or_else(|| winit_window.map(|window| window.scale_factor()))
                    .unwrap_or(1.0);
                self.cursor = Some(((position.x / scale) as f32, (position.y / scale) as f32));
                if let Some(window) = winit_window.filter(|_| self.edges) {
                    let size = window.inner_size();
                    let edge = (window.is_resizable()
                        && !window.is_maximized()
                        && window.fullscreen().is_none())
                    .then(|| {
                        edge_at(
                            position.x,
                            position.y,
                            f64::from(size.width),
                            f64::from(size.height),
                            EDGE * scale,
                        )
                    })
                    .flatten();
                    if edge != self.edge {
                        // Off an edge the arrow goes back to the default and
                        // Slint puts its own on at the next change of hover.
                        window.set_cursor(edge.map_or(CursorIcon::Default, edge_cursor));
                        self.edge = edge;
                    }
                    if edge.is_some() {
                        return EventResult::PreventDefault;
                    }
                }
            }
            WindowEvent::CursorLeft { .. } => self.edge = None,
            WindowEvent::MouseInput {
                state: ElementState::Pressed,
                button: MouseButton::Left,
                ..
            } if self.edge.is_some() => {
                if let (Some(window), Some(edge)) = (winit_window, self.edge) {
                    let _ = window.drag_resize_window(edge);
                }
                return EventResult::PreventDefault;
            }
            WindowEvent::MouseInput {
                state: ElementState::Pressed,
                ..
            } => {
                if let (Some(window), Some((x, y))) = (slint_window, self.cursor)
                    && press_misses_focused_input(window, x, y)
                {
                    (self.on_pressed_away)();
                }
            }
            _ => {}
        }
        EventResult::Propagate
    }

    fn about_to_wait(&mut self, _event_loop: &ActiveEventLoop) -> EventResult {
        if let Ok(mut arrived) = self.arrived.lock() {
            self.pending.append(&mut arrived);
        }
        if !self.pending.is_empty() {
            (self.on_dropped)(std::mem::take(&mut self.pending));
        }
        EventResult::Propagate
    }

    fn exiting(&mut self, _event_loop: &ActiveEventLoop) -> EventResult {
        // Before winit closes its display, which the listener reads.
        self.wayland = None;
        EventResult::Propagate
    }
}

/// The Wayland drop listener for `window`, when the window is a Wayland
/// one: it puts each drop's paths in `arrived` and wakes the event loop,
/// whose next `about_to_wait` hands them over. None on any other display.
#[cfg(not(target_os = "android"))]
fn listen_for_wayland_drops(
    window: &WinitWindow,
    arrived: &std::sync::Arc<std::sync::Mutex<Vec<PathBuf>>>,
) -> Option<crate::wayland_drop::Listener> {
    use slint::winit_030::winit::raw_window_handle::{
        HasDisplayHandle, HasWindowHandle, RawDisplayHandle, RawWindowHandle,
    };
    let display = window.display_handle().ok()?.as_raw();
    let surface = window.window_handle().ok()?.as_raw();
    let (RawDisplayHandle::Wayland(display), RawWindowHandle::Wayland(surface)) =
        (display, surface)
    else {
        return None;
    };
    let arrived = std::sync::Arc::clone(arrived);
    let sink = move |paths: Vec<PathBuf>| {
        if let Ok(mut held) = arrived.lock() {
            held.extend(paths);
        }
        // An empty errand, run on the loop's thread: what wakes it.
        let _ = slint::invoke_from_event_loop(|| {});
    };
    // SAFETY: winit keeps the display for the life of the event loop, and
    // the listener is dropped in `exiting`, before the loop is.
    unsafe { crate::wayland_drop::Listener::start(display.display, surface.surface, sink) }
}

/// Whether the window draws the macOS traffic lights over its own strip.
pub const MACOS: bool = cfg!(target_os = "macos");

/// Whether the window is a phone's: one screen, held upright, driven by a
/// finger. The editor then wears the phone shell (ui/phone/) rather than
/// the strip and the dock, whatever the screen's size - a tablet is a big
/// phone here, not a small desk. True on Android and iOS; on a desk,
/// `CONCAT_PHONE=1` in the environment asks for the same shell in a window,
/// which is how the phone layout is worked on without a phone. That window
/// keeps the platform's own title bar - the phone shell has no strip to
/// drag by and no window buttons, and a phone has no such buttons to show
/// over its screen - so the desk's chrome sits above the phone's screen,
/// the way a simulator's does, and never on it.
pub fn phone() -> bool {
    cfg!(any(target_os = "android", target_os = "ios"))
        || std::env::var_os("CONCAT_PHONE").is_some_and(|value| !value.is_empty() && value != "0")
}

/// Chooses and installs the backend, and hands back the device the
/// renderer and the engine's compositor share, when there is one.
///
/// `on_files_dropped` fires on the event-loop thread with the paths of a
/// file (or several) dragged in from outside the window - Finder, Explorer,
/// a file manager - batched into one call per drag. It is taken here,
/// before the window exists, because the backend - and the hook into its
/// event loop that OS drops arrive through - has to be selected before
/// anything is built on top of it; see [`DropHandler`]. `on_focused` fires
/// the same way each time the window is brought back to the front.
#[cfg(not(target_os = "android"))]
pub fn select_backend(
    on_files_dropped: impl Fn(Vec<PathBuf>) + 'static,
    on_pressed_away: impl Fn() + 'static,
    on_focused: impl Fn() + 'static,
) -> Result<Option<Gpu>, PlatformError> {
    // The device the renderer and the monitor share. Taken first, because
    // the backend is selected with it.
    let gpu = Gpu::acquire();
    match &gpu {
        None => log::warn!("no GPU adapter; the monitor composites on the CPU"),
        // A software adapter is refused by Slint's selector unless this
        // variable says otherwise: it enumerates the adapters on the instance
        // it was handed, finds none that is a GPU, and `select` fails with
        // "no GPU-backed WGPU adapter is available". From a double-clicked
        // GUI build that failure went to a console nobody could see, and the
        // app just never appeared. Setting it here is what the reporter did
        // by hand, and the window, the editing and the export all worked on
        // WARP - so the app does it for them and says so in the log.
        // https://github.com/jub0t/Concat/issues/135
        Some(gpu) if gpu.is_software() => {
            log::warn!("the GPU adapter is a software rasteriser; the window will render slowly");
            // SAFETY: the process is single-threaded at this point - the
            // backend, the engine's threads and the window all come after
            // this function - so nothing reads the environment concurrently.
            unsafe { std::env::set_var("SLINT_WGPU_CPU", "1") };
        }
        Some(_) => {}
    }

    let mut selector = slint::BackendSelector::new()
        .backend_name("winit".into())
        .with_winit_custom_application_handler(DropHandler::new(
            on_files_dropped,
            on_pressed_away,
            on_focused,
        ));
    selector = match &gpu {
        Some(gpu) => selector.require_wgpu_30(gpu.configuration()),
        None => {
            // Without a shared device, ask for the platform's own API by
            // name: Skia picks its surface from a cfg chain, and requiring
            // one turns a silent fall back to the CPU rasteriser into a
            // refusal to start, which is a fault you can see.
            #[cfg(target_vendor = "apple")]
            {
                selector.require_metal()
            }
            #[cfg(target_family = "windows")]
            {
                selector.require_d3d()
            }
            #[cfg(not(any(target_vendor = "apple", target_family = "windows")))]
            {
                selector
            }
        }
    };

    // The custom title bar. The window draws its own strip, so the
    // platform's is not wanted - but each platform is asked in its own way.
    //
    // macOS keeps the real title bar and makes it invisible: transparent,
    // untitled, with the content view under it. That is what keeps the
    // traffic lights, which are the window's and not ours to draw, and the
    // strip leaves 80px for them (title-bar.slint).
    //
    // Everywhere else the decorations go entirely and the strip carries its
    // own minimise, maximise and close. On Windows winit keeps WS_SIZEBOX
    // when the caption goes, so the edges still resize, and the undecorated
    // shadow keeps the DWM drop shadow the caption would otherwise have
    // taken with it.
    //
    // The attributes below are the window's first state; what keeps the
    // decorations off is the Slint window's `no-frame` (app.slint), which
    // the winit backend re-applies after the window is made. On Wayland
    // without it GNOME's bar came back above the strip:
    // https://github.com/jub0t/Concat/issues/97
    // https://github.com/jub0t/Concat/issues/145
    //
    // None of it for the phone shell shown on a desk: that has no strip of
    // its own, so the platform's title bar stays, buttons and all, above
    // the phone's screen rather than over it. See `phone`.
    let desk = !phone();
    #[cfg(target_os = "macos")]
    if desk {
        use slint::winit_030::winit::platform::macos::WindowAttributesExtMacOS;
        selector = selector.with_winit_window_attributes_hook(|attributes| {
            attributes
                .with_titlebar_transparent(true)
                .with_title_hidden(true)
                .with_fullsize_content_view(true)
        });
    }
    #[cfg(target_os = "windows")]
    if desk {
        use slint::winit_030::winit::platform::windows::WindowAttributesExtWindows;
        selector = selector.with_winit_window_attributes_hook(|attributes| {
            attributes
                .with_decorations(false)
                .with_undecorated_shadow(true)
        });
    }
    #[cfg(not(any(target_os = "macos", target_os = "windows", target_os = "android")))]
    if desk {
        selector = selector
            .with_winit_window_attributes_hook(|attributes| attributes.with_decorations(false));
    }
    selector.select()?;
    // The desktop entry's name (concat.desktop, in every Linux package and
    // the flake), as the window's Wayland app_id and X11 class, so a dock
    // or a task switcher files the running window under the launcher it
    // came from - its icon, its pin - rather than as an unknown app. Slint
    // ignores it off Linux and the BSDs.
    let _ = slint::set_xdg_app_id("concat");
    Ok(gpu)
}

/// Tells the user the window could not start, in a dialog of the platform's
/// own, because the console the error would otherwise go to is not one a
/// double-clicked build has: on Windows a GUI subsystem binary has no
/// standard error, and the app was exiting with the reason written to
/// nowhere. The log file is named so the reader has something to attach.
/// https://github.com/jub0t/Concat/issues/135
pub fn report_startup_failure(error: &str) {
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    {
        let mut description = format!("Concat could not start.\n\n{error}");
        if let Some(path) = concat_host::logs::current() {
            description.push_str(&format!("\n\nLog: {}", path.display()));
        }
        rfd::MessageDialog::new()
            .set_level(rfd::MessageLevel::Error)
            .set_title("Concat")
            .set_description(description)
            .set_buttons(rfd::MessageButtons::Ok)
            .show();
    }
    #[cfg(any(target_os = "android", target_os = "ios"))]
    let _ = error;
}

/// Whether the strip should draw its own window buttons: everywhere the
/// platform's decorations were taken off, which is everywhere but macOS,
/// where the traffic lights stay the window's.
pub const OWN_WINDOW_BUTTONS: bool = !MACOS;

/// A shortcut as this platform writes it, from the parts a `@keys` takes:
/// `["Control", "Shift", "Z"]` reads ⇧⌘Z on a Mac and Ctrl+Shift+Z on
/// Windows and Linux, because Slint takes `Control` for ⌘ there. The same
/// parts as the binding in app.slint, so a menu row names the keys that
/// work on the machine it is shown on.
pub fn keys(parts: &[&str]) -> String {
    slint::Keys::from_parts(parts.iter().copied())
        .map(|keys| keys.to_string())
        .unwrap_or_default()
}

/// The delete key as this platform writes it: ⌫ on a Mac, Del elsewhere,
/// with Shift in front for the ripple delete. Either key deletes
/// (app.slint); these are the names each platform's own menus use.
pub fn delete_key(shift: bool) -> String {
    let apple = cfg!(any(target_os = "macos", target_os = "ios"));
    match (apple, shift) {
        (true, false) => "⌫".into(),
        (true, true) => "⇧⌫".into(),
        (false, false) => "Del".into(),
        (false, true) => "Shift+Del".into(),
    }
}

/// Minimises the window: the strip's first button.
pub fn minimize(window: &slint::Window) {
    #[cfg(not(target_os = "android"))]
    {
        use slint::winit_030::WinitWindowAccessor;
        window.with_winit_window(|window| {
            window.set_minimized(true);
        });
    }
    #[cfg(target_os = "android")]
    let _ = window;
}

/// Maximises a window that opened larger than its screen. The window asks
/// for 1400 by 900 and may not shrink past 900 by 560, both in logical
/// pixels, and a 1920 by 1080 laptop at 150 % has 1280 by 720 of them less
/// its taskbar: the window opened past the screen's edges, with its corner
/// handles out of reach, and could not be moved back or made smaller
/// (#347). Maximised it fills the work area, taskbar and all, and the
/// title strip's double-click restores it.
/// macOS shrinks a window to its screen by itself, so there it is left be.
#[cfg(not(target_os = "android"))]
fn fit_to_screen(window: &WinitWindow) {
    if cfg!(target_os = "macos") {
        return;
    }
    let Some(monitor) = window.current_monitor() else {
        return;
    };
    let (screen, size) = (monitor.size(), window.outer_size());
    // A taskbar or a dock takes up to about a tenth of the height; winit
    // knows the monitor and not its work area.
    let room = f64::from(screen.height) * 0.9;
    if size.width > screen.width || f64::from(size.height) > room {
        log::info!(
            "window: {}x{} does not fit the screen's {}x{}; maximised",
            size.width,
            size.height,
            screen.width,
            screen.height
        );
        window.set_maximized(true);
    }
}

/// Whether the window is currently maximised, for the strip to pick the
/// maximise or the restore glyph. False where there is no such state.
pub fn is_maximized(window: &slint::Window) -> bool {
    #[cfg(not(target_os = "android"))]
    {
        use slint::winit_030::WinitWindowAccessor;
        window
            .with_winit_window(|window| window.is_maximized())
            .unwrap_or(false)
    }
    #[cfg(target_os = "android")]
    {
        let _ = window;
        false
    }
}

/// On Android the activity installed the backend before calling in, and
/// that backend draws on a device of its own; the monitor composites on the
/// CPU and hands the renderer finished pixels. Android has no OS drag to
/// wire up - a file arrives through the document picker instead - so
/// `on_files_dropped` is taken only to keep the signature the same as the
/// desktop's and is never called.
#[cfg(target_os = "android")]
pub fn select_backend(
    on_files_dropped: impl Fn(Vec<PathBuf>) + 'static,
    // Android has no pointer to press away with; the screen's own keyboard
    // dismisses, and the field goes with it.
    _on_pressed_away: impl Fn() + 'static,
    // Nor a window that loses and regains the front: the activity owns the
    // screen, and a file comes back through the picker.
    _on_focused: impl Fn() + 'static,
) -> Result<Option<Gpu>, PlatformError> {
    let _ = on_files_dropped;
    Ok(None)
}

/// Starts a window drag from the title strip.
pub fn begin_drag(window: &slint::Window) {
    #[cfg(not(target_os = "android"))]
    {
        use slint::winit_030::WinitWindowAccessor;
        window.with_winit_window(|window| {
            let _ = window.drag_window();
        });
    }
    #[cfg(target_os = "android")]
    let _ = window;
}

/// Maximises the window, or restores it: the title strip's double-click.
pub fn toggle_maximize(window: &slint::Window) {
    #[cfg(not(target_os = "android"))]
    {
        use slint::winit_030::WinitWindowAccessor;
        window.with_winit_window(|window| {
            window.set_maximized(!window.is_maximized());
        });
    }
    #[cfg(target_os = "android")]
    let _ = window;
}

/// Asks for a folder, starting at `start` when there is one.
pub fn pick_folder(title: &str, start: &str) -> Option<PathBuf> {
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    {
        let mut dialog = rfd::FileDialog::new().set_title(title);
        if let Some(folder) = existing_folder(start) {
            dialog = dialog.set_directory(folder);
        }
        dialog.pick_folder()
    }
    #[cfg(any(target_os = "android", target_os = "ios"))]
    {
        let _ = (title, start);
        None
    }
}

/// Where a folder dialog asked to start at `start` can open: `start`
/// itself, or the nearest folder above it that exists. A new project's
/// default, `<Desktop>/Concat`, is not made until the first project is, and
/// GNOME's chooser (Nautilus, behind the portal) fails on a folder that is
/// not there, where GTK's quietly opens elsewhere.
/// https://github.com/jub0t/Concat/issues/331
#[cfg(not(any(target_os = "android", target_os = "ios")))]
fn existing_folder(start: &str) -> Option<&std::path::Path> {
    std::path::Path::new(start)
        .ancestors()
        .find(|folder| folder.is_dir())
}

/// What a phone does when asked for files: shows the system's picker for
/// the kinds asked for (see [`PickKinds`]) and calls back, later, with what
/// was chosen - an empty list for nothing. Installed by the phone's own
/// crate before the window runs; see [`install_file_picker`].
#[cfg(any(target_os = "android", target_os = "ios"))]
pub type FilePicker = Box<dyn Fn(PickKinds, Box<dyn FnOnce(Vec<PathBuf>) + Send>) + Send + Sync>;

/// What a phone's picker is asked to offer, from the desktop dialog's
/// list of extensions: media - some of video, sound and pictures - which
/// the phone's own pickers know by kind, or files by their extensions
/// (subtitles, fonts), which a phone's providers type so variously that
/// the extensions are all there is to go on.
#[cfg(any(target_os = "android", target_os = "ios", test))]
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum PickKinds {
    /// Media, by kind; every kind when no list was given.
    Media {
        video: bool,
        audio: bool,
        image: bool,
    },
    /// Anything else, by extension, lowercase and without the dot.
    Files(Vec<String>),
}

#[cfg(any(target_os = "android", target_os = "ios", test))]
impl PickKinds {
    /// The kinds a dialog filter's extensions ask for. No filter is every
    /// kind of media, as Import asks.
    pub fn of(extensions: Option<&[&str]>) -> Self {
        let Some(extensions) = extensions.filter(|list| !list.is_empty()) else {
            return PickKinds::Media {
                video: true,
                audio: true,
                image: true,
            };
        };
        let (mut video, mut audio, mut image) = (false, false, false);
        for extension in extensions {
            match media_kind(extension) {
                Some(MediaKind::Video) => video = true,
                Some(MediaKind::Audio) => audio = true,
                Some(MediaKind::Image) => image = true,
                None => {
                    return PickKinds::Files(
                        extensions
                            .iter()
                            .map(|ext| ext.to_ascii_lowercase())
                            .collect(),
                    );
                }
            }
        }
        PickKinds::Media {
            video,
            audio,
            image,
        }
    }
}

#[cfg(any(target_os = "android", target_os = "ios", test))]
enum MediaKind {
    Video,
    Audio,
    Image,
}

#[cfg(any(target_os = "android", target_os = "ios", test))]
/// Which kind of media a file with this extension is, if it is media.
fn media_kind(extension: &str) -> Option<MediaKind> {
    match extension.to_ascii_lowercase().as_str() {
        "mp4" | "mov" | "mkv" | "webm" | "avi" | "m4v" | "mts" | "m2ts" | "3gp" => {
            Some(MediaKind::Video)
        }
        "mp3" | "wav" | "aac" | "m4a" | "flac" | "ogg" | "opus" | "aif" | "aiff" => {
            Some(MediaKind::Audio)
        }
        "png" | "jpg" | "jpeg" | "webp" | "gif" | "bmp" | "tif" | "tiff" | "heic" | "heif" => {
            Some(MediaKind::Image)
        }
        _ => None,
    }
}

#[cfg(any(target_os = "android", target_os = "ios"))]
static FILE_PICKER: std::sync::OnceLock<FilePicker> = std::sync::OnceLock::new();

/// Installs the picker a phone answers [`pick_files_async`] with. Once;
/// a second call is ignored.
#[cfg(any(target_os = "android", target_os = "ios"))]
pub fn install_file_picker(picker: FilePicker) {
    let _ = FILE_PICKER.set(picker);
}

/// What a phone does with a finished export: moves the file to where the
/// phone's own gallery and file manager show it, and says where. The
/// export itself writes into the app's own folder, which on a phone
/// nothing but the app can open. Installed by the phone's own crate before
/// the window runs, where the phone can be asked at all; see
/// [`install_export_publisher`].
#[cfg(any(target_os = "android", target_os = "ios"))]
pub struct ExportPublisher {
    /// Where the files go, as the phone names it: "Movies/Concat".
    pub folder: String,
    /// Moves the file there and answers with its path under the phone's
    /// storage, or with why it could not, leaving the file where it was.
    /// It copies a whole video, so it is called off the window's thread.
    pub publish: Box<dyn Fn(&std::path::Path) -> Result<String, String> + Send + Sync>,
    /// The same for a small file that is not a video - a subtitle file -
    /// with its MIME type: moved to where the phone's file manager shows
    /// it (Android's Download/Concat, the iPhone's Files), never over
    /// another file, and answered with where, as the person would look
    /// for it.
    pub publish_document:
        Box<dyn Fn(&std::path::Path, &str) -> Result<String, String> + Send + Sync>,
}

#[cfg(any(target_os = "android", target_os = "ios"))]
static EXPORT_PUBLISHER: std::sync::OnceLock<ExportPublisher> = std::sync::OnceLock::new();

/// Installs where a phone puts a finished export. Once; a second call is
/// ignored.
#[cfg(any(target_os = "android", target_os = "ios"))]
pub fn install_export_publisher(publisher: ExportPublisher) {
    let _ = EXPORT_PUBLISHER.set(publisher);
}

/// Whether the app may record from the microphone, asking when it has not
/// been told: on a phone, false puts the system's question up and comes
/// back at once, and the answer is read the next time this is asked.
/// Installed by the phone's own crate; see [`install_microphone_access`].
#[cfg(any(target_os = "android", target_os = "ios"))]
pub type MicrophoneAccess = Box<dyn Fn() -> bool + Send + Sync>;

#[cfg(any(target_os = "android", target_os = "ios"))]
static MICROPHONE_ACCESS: std::sync::OnceLock<MicrophoneAccess> = std::sync::OnceLock::new();

/// Installs how a phone is asked for its microphone. Once; a second call
/// is ignored.
#[cfg(any(target_os = "android", target_os = "ios"))]
pub fn install_microphone_access(access: MicrophoneAccess) {
    let _ = MICROPHONE_ACCESS.set(access);
}

/// Opens a web address in the browser, on a phone. Installed by the phone's
/// own crate; see [`install_link_opener`].
#[cfg(target_os = "android")]
pub type LinkOpener = Box<dyn Fn(&str) -> Result<(), String> + Send + Sync>;

#[cfg(target_os = "android")]
static LINK_OPENER: std::sync::OnceLock<LinkOpener> = std::sync::OnceLock::new();

/// Installs how a phone opens a web address. Once; a second call is
/// ignored.
#[cfg(target_os = "android")]
pub fn install_link_opener(opener: LinkOpener) {
    let _ = LINK_OPENER.set(opener);
}

/// Opens a web address in the system's browser: the launch screen's
/// guides, the repository, the release notes. A desktop hands it to the
/// platform's opener; Android to an ACTION_VIEW intent through the
/// activity, iOS to UIApplication. An address that goes nowhere says why.
pub fn open_link(url: &str) -> Result<(), String> {
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    {
        opener::open(url).map_err(|error| error.to_string())
    }
    #[cfg(target_os = "android")]
    {
        match LINK_OPENER.get() {
            Some(open) => open(url),
            None => Err(format!("this device has no browser to open {url} with")),
        }
    }
    #[cfg(target_os = "ios")]
    {
        crate::ios::open_link(url)
    }
}

/// Whether the microphone may be opened now. A desktop asks when the
/// device opens, which is the system's business, so it is always yes here;
/// a phone with nothing installed is too, and the device's own error says
/// the rest.
pub fn microphone_allowed() -> bool {
    #[cfg(any(target_os = "android", target_os = "ios"))]
    {
        MICROPHONE_ACCESS.get().is_none_or(|access| access())
    }
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    {
        true
    }
}

/// Where a finished export ends up on this device when that is not the
/// folder the export writes into: a phone's "Movies/Concat". None on a
/// desktop, and on a phone too old to be asked, where the file stays where
/// the sheet says.
pub fn published_folder() -> Option<&'static str> {
    #[cfg(any(target_os = "android", target_os = "ios"))]
    {
        EXPORT_PUBLISHER
            .get()
            .map(|publisher| publisher.folder.as_str())
    }
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    {
        None
    }
}

/// Hands a finished export to the phone on a thread of its own, and calls
/// `on_done` with where it went or why it did not - on that thread; the
/// caller hops to the window's. False when there is nothing to hand it to:
/// the file stays where it was written, and `on_done` is never called.
pub fn publish_export(
    path: std::path::PathBuf,
    on_done: impl FnOnce(Result<String, String>) + Send + 'static,
) -> bool {
    #[cfg(any(target_os = "android", target_os = "ios"))]
    {
        let Some(publisher) = EXPORT_PUBLISHER.get() else {
            return false;
        };
        std::thread::Builder::new()
            .name("export publish".into())
            .spawn(move || on_done((publisher.publish)(&path)))
            .is_ok()
    }
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    {
        let _ = (path, on_done);
        false
    }
}

/// [`publish_export`] for a document - a subtitle file - of MIME type
/// `mime`: handed to the phone on a thread of its own, `on_done` told
/// where it went or why not. False when there is nothing to hand it to -
/// a desktop, where the file was written where the person chose, or a
/// phone too old to be asked - and `on_done` is never called.
pub fn publish_document(
    path: std::path::PathBuf,
    mime: &'static str,
    on_done: impl FnOnce(Result<String, String>) + Send + 'static,
) -> bool {
    #[cfg(any(target_os = "android", target_os = "ios"))]
    {
        let Some(publisher) = EXPORT_PUBLISHER.get() else {
            return false;
        };
        std::thread::Builder::new()
            .name("document publish".into())
            .spawn(move || on_done((publisher.publish_document)(&path, mime)))
            .is_ok()
    }
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    {
        let _ = (path, mime, on_done);
        false
    }
}

/// Asks for files and calls `on_picked` with them, on whichever thread the
/// platform answers from - the caller hops to the window's thread itself.
///
/// On a desktop the dialog blocks and the callback runs before this
/// returns. On a phone the system's picker is another screen: this returns
/// at once and the callback comes when the picker is dismissed, through
/// the picker the phone's crate installed. `filter` is the desktop
/// dialog's; a phone's picker is asked for the same kinds of file, as
/// [`PickKinds`] reads them from it.
pub fn pick_files_async(
    title: &str,
    filter: Option<(&str, &[&str])>,
    on_picked: impl FnOnce(Vec<PathBuf>) + Send + 'static,
) {
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    {
        if let Some(paths) = pick_files(title, filter) {
            on_picked(paths);
        }
    }
    #[cfg(any(target_os = "android", target_os = "ios"))]
    {
        let _ = title;
        let kinds = PickKinds::of(filter.map(|(_, extensions)| extensions));
        match FILE_PICKER.get() {
            Some(picker) => picker(kinds, Box::new(on_picked)),
            None => log::warn!("no file picker on this platform yet"),
        }
    }
}

/// Asks where to write a file, starting in `directory` with `name` filled
/// in, limited to the family `filter` names. None when the dialog was
/// dismissed - and on a phone, which has no such dialog: the caller writes
/// where it would have suggested, and says where.
pub fn save_file(
    title: &str,
    directory: &std::path::Path,
    name: &str,
    filter: (&str, &[&str]),
) -> Option<PathBuf> {
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    {
        let (family, extensions) = filter;
        rfd::FileDialog::new()
            .set_title(title)
            .set_directory(directory)
            .set_file_name(name)
            .add_filter(family, extensions)
            .save_file()
    }
    #[cfg(any(target_os = "android", target_os = "ios"))]
    {
        let _ = (title, directory, name, filter);
        None
    }
}

/// Asks for files. `filter` names a family and its extensions, and limits
/// the dialog to them.
pub fn pick_files(title: &str, filter: Option<(&str, &[&str])>) -> Option<Vec<PathBuf>> {
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    {
        let mut dialog = rfd::FileDialog::new().set_title(title);
        if let Some((name, extensions)) = filter {
            dialog = dialog.add_filter(name, extensions);
        }
        dialog.pick_files()
    }
    #[cfg(any(target_os = "android", target_os = "ios"))]
    {
        let _ = (title, filter);
        None
    }
}

/// Shows a written file in the platform's file manager.
///
/// A phone has no file manager to hand a path to, and says so rather than
/// appearing to work: a control that silently does nothing is worse than one
/// that explains itself. The path is in the message, which is the part a
/// developer on a cable can still use.
pub fn reveal(path: &str) -> Result<(), String> {
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    {
        opener::reveal(path).map_err(|error| error.to_string())
    }
    #[cfg(any(target_os = "android", target_os = "ios"))]
    {
        Err(format!(
            "this device has no file manager to open {path} with"
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A menu row names the keys the way the platform it runs on does:
    /// the Mac's glyphs there, Ctrl and Shift spelled out everywhere else.
    #[test]
    fn shortcuts_read_the_way_the_platform_writes_them() {
        if cfg!(target_os = "macos") {
            assert_eq!(keys(&["Control", "Shift", "Z"]), "⇧⌘Z");
            assert_eq!(keys(&["Control", ","]), "⌘,");
            assert_eq!(delete_key(true), "⇧⌫");
        } else {
            assert_eq!(keys(&["Control", "Shift", "Z"]), "Ctrl+Shift+Z");
            assert_eq!(keys(&["Control", ","]), "Ctrl+,");
            assert_eq!(delete_key(true), "Shift+Del");
        }
    }

    /// The frame's edges resize, corners diagonally, and the middle of the
    /// window is nobody's edge.
    #[test]
    fn a_press_near_the_frame_finds_its_edge() {
        let at = |x, y| edge_at(x, y, 1000.0, 800.0, 6.0);
        assert_eq!(at(500.0, 400.0), None);
        assert_eq!(at(2.0, 400.0), Some(ResizeDirection::West));
        assert_eq!(at(997.0, 400.0), Some(ResizeDirection::East));
        assert_eq!(at(500.0, 0.0), Some(ResizeDirection::North));
        assert_eq!(at(500.0, 799.0), Some(ResizeDirection::South));
        assert_eq!(at(1.0, 1.0), Some(ResizeDirection::NorthWest));
        assert_eq!(at(999.0, 799.0), Some(ResizeDirection::SouthEast));
        assert_eq!(at(6.0, 400.0), None);
    }

    /// A folder dialog opens on a folder that exists: a default location
    /// not made yet opens on the folder it would be made in, one that
    /// exists opens as given, and no location asks for none.
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    #[test]
    fn a_folder_dialog_starts_at_a_folder_that_exists() {
        let root = std::env::temp_dir().join(format!("concat-pick-{}", std::process::id()));
        std::fs::create_dir_all(&root).unwrap();
        let missing = root.join("Concat");
        assert_eq!(
            existing_folder(&missing.to_string_lossy()),
            Some(root.as_path())
        );
        assert_eq!(
            existing_folder(&root.to_string_lossy()),
            Some(root.as_path())
        );
        assert_eq!(existing_folder(""), None);
        std::fs::remove_dir_all(&root).unwrap();
    }

    /// A phone's picker is asked for what the desktop dialog would show:
    /// media by kind, and subtitles or fonts by their extensions - an
    /// .srt is not media, and a picker that offered only media hid it.
    #[test]
    fn a_phone_picker_is_asked_for_the_dialogs_kinds() {
        let every = PickKinds::Media {
            video: true,
            audio: true,
            image: true,
        };
        assert_eq!(PickKinds::of(None), every);
        assert_eq!(PickKinds::of(Some(&["mp4", "WAV", "png"])), every);
        assert_eq!(
            PickKinds::of(Some(&["mp3", "flac"])),
            PickKinds::Media {
                video: false,
                audio: true,
                image: false,
            }
        );
        assert_eq!(
            PickKinds::of(Some(&["SRT"])),
            PickKinds::Files(vec!["srt".to_owned()])
        );
        assert_eq!(
            PickKinds::of(Some(&["ttf", "otf"])),
            PickKinds::Files(vec!["ttf".to_owned(), "otf".to_owned()])
        );
    }
}
